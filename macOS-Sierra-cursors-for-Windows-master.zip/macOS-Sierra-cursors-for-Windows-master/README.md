![macOS Sierra cursors for Windows (only 200%)](https://github.com/antiden/macOS-Sierra-cursors-for-Windows/blob/master/screenshot.jpg)

# macOS Sierra cursors for Windows (only 200%)

Custom cursor macOS Sierra pack for Windows in 4K and scale 200%

## How to use it:

1. Right click Install.inf and click «Install» 
2. Go to Control Panel → Mouse and choose «macOS Sierra 200» scheme. 
3. Apply and enjoy the best cursors ever!

## Authors

* **antiden** - [CODERTEAM_](https://coderteam.ru)
* Vector icons **daviddarnes** - [daviddarnes](https://github.com/daviddarnes/mac-cursors)

## License

This software is released under the [Apple User Agreement](http://images.apple.com/legal/sla/docs/OSX1011.pdf).

This project is licensed under the MIT License - see the [LICENSE.md](https://rem.mit-license.org/) file for details
